<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-3">

        </div>
        <div class="col-md-6">
            <div class="card">
                <div class="card-header text-center">
                    Your Purchase History
                </div>
                <div class="card-body">
                    <?php if(count($events) > 0): ?>
                    <ul class="list-group">
                    
                        <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="list-group-item"> <a href="/events/<?php echo e($event->id); ?>"> <?php echo e($event->title); ?> </a> <p class="float-right p-0 m-0" style="color:darkgrey;font-weight:light;font-size:0.8rem;;">Purchased at: <?php echo e($event->date); ?></p> </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    </ul>
                    <?php else: ?>
                        <p class="text-center">You havent made a purchase yet!</p>
                    <?php endif; ?>

                </div>
            </div>
            
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>