<?php if(isset($errors) && $errors != '[]'): ?>
    <div class="alert alert-dismissable alert-danger text-center">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>

            <li><strong><?php echo $errors; ?></strong></li>

    </div>
<?php endif; ?>
