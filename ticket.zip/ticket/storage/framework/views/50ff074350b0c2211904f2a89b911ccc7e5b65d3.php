<div class="">
  <form class="" action="<?php echo e(route('HomeController.email')); ?>" method="post">
    <?php echo method_field('PUT'); ?>
      <?php echo e(csrf_field); ?>

      <input type="text" name="name" value="">
      <input type="submit" name="submit" value="send">
  </form>
</div>
