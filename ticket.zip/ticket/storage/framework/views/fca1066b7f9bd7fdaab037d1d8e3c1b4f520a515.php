<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <div class="row">
    <div class="col-md-3">

    </div>
    <div class="col-md-6">
      <div class="card">
        <div class="card-header text-center">
          Add An Event
        </div>
        <div class="card-body">
          <form class="" action="<?php echo e(route('events.store')); ?>" enctype="multipart/form-data" method="POST">
            <?php echo e(csrf_field()); ?>

            <input type="text" class="form-control" name="title" placeholder="Input Event Title" value="">
            <br>
            <select class="form-control" name="category">
              <option value="">Choose Event Category</option>
              <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <br>
            <textarea name="desc" rows="8" id="article-ckeditor" cols="80" placeholder="Input Event Description" class="form-control"></textarea>

            <input type="file" name="cover" class="form-control mt-2">

            <input type="submit" name="submit" class="btn btn-sm btn-primary mt-2" value="submit">

          </div>
          </form>
        </div>
      </div>
    </div>

  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>