<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-md-3">

  </div>
  <div class="col-md-6">
    <div class="card card-primary">
      <div class="card-header text-center">
      My  Events
      </div>
    <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="card-body">
        <div class="row">
          <div class="col-md-4">
            <img src="/storage/images/<?php echo e($event->cover); ?>" style="width:100%;height:100px;" class="img-responsive" alt="">
          </div>
          <div class="col-md-8">
            
            <div class="text-center">
              <h4><?php echo e($event->title); ?></h4>
            </div>
    
            <div class="">
              <?php echo e($event->description); ?>

    
              <div class="float-right">
                <ul class="list-inline list-unstyled">
                  <li class="list-inline-item"><a href="/events/<?php echo e($event->id); ?>" class="btn btn-info btn-sm">View</a></li>
                </ul>
              </div>
    
    
            </div>
          </div>
          </div>
        
        <hr>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div>

    <?php echo e($events->links()); ?>      
    </div>
  </div>
  <div class="col-md-3">
    <div class="card">
      <div class="card-body">
        <a href="/events/create">Create new Event</a>
      </div>
    </div>
  </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>