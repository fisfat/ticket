<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-md-3">

  </div>
  <div class="col-md-6">
    <div class="card card-primary">
      <div class="card-header text-center">
        Events
      </div>
      <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="card-body">
        <div class="text-center">
          <h4><?php echo e($cat->title); ?></h4>
        </div>

        <div class="">
          <?php echo e($cat->description); ?>

        </div>
        <hr>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>