<?php if( session()->has('success')): ?>
<div class="alert alert-dismissable fade show alert-success">
  <button type="button" class="close" data-dismiss="alert" aria-label="close" name="button">
    <span aria-hidden="true">&times;</span>
  </button>
  <strong>
    <?php echo session()->get('success'); ?>

  </strong>
</div>

<?php endif; ?>
