<?php if($errors != '[]'): ?>
    
        <div class="alert alert-dismissable text-center alert-danger">
            <?php echo $errors; ?>

        </div>
    
<?php endif; ?>

<?php if(session('error')): ?>
    <div class="alert alert-dismissable text-center alert-danger">
        <?php echo session('error'); ?>

    </div>
<?php endif; ?>

<?php if(session('success')): ?>
    <div class="alert alert-dismissable text-center alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>