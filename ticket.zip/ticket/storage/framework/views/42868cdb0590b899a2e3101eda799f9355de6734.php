<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <div class="row">
      <div class="col-md-3">
        <div class="card">
          <div class="card-header text-center">
            Categories
          </div>
          <div class="card-body">
            <ul class="list-unstyled list-group">
              <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li class="list-group-item"> <a href="/categories/<?php echo e($category->id); ?>"><?php echo e($category->name); ?></a> </li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
          </div>
        </div>
      </div>

        <div class="col-md-6">
            <div class="card">
                <div class="card-header text-center">Dashboard</div>

                <div class="card-body">
                    
                    <?php if(count($events) > 0): ?>
                      <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                      <div class="row">
                          <div class="col-md-4">
                            <img src="/storage/images/<?php echo e($event->cover); ?>" style="width:100%;height:100px;" class="img-responsive" alt="">
                          </div>
                          <div class="col-md-8">
                            
                            <div class="text-center">
                              <h4><?php echo e($event->title); ?></h4>
                            </div>
                    
                            <div class="">
                              <?php echo e($event->description); ?>

                    
                              <div class="float-right">
                                <ul class="list-inline list-unstyled">
                                  <li class="list-inline-item"><a href="/events/<?php echo e($event->id); ?>" class="btn btn-info btn-sm">View</a></li>
                                </ul>
                              </div>
                    
                    
                            </div>
                          </div>
                          </div>
                        <hr>

                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <p class="text-center">No post found!</p>
                    <?php endif; ?>


                </div>
                       
                
            </div>
            <div class="float-right mt-3">
              <?php echo e($events->links()); ?>

            </div>
            
        </div>
        
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>